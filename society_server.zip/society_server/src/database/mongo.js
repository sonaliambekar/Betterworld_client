var mongoose = require('mongoose');

var mongoURI;

mongoose.connection.on('open', function(ref){
    console.log("Connected to Mongo server");
});

mongoose.connection.on('error', function(err){
    console.log("Could not connect to Database");
    return console.log(err);
});

mongoURI = "mongodb://localhost/meanstack";

module.exports = mongoose.connect(mongoURI);