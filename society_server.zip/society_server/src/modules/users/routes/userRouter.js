var express = require ('express');
var router =  express.Router();

//var userController = require('./../controllers/userController');

import userController from './../controllers/userController';
import userValidator from './../validator/userValidator';


//router.get('/test', function(req, res){
   // res.send("Routing Works");
//})
//var userControllerobj =new userController();
// router.get('/count', userControllerobj.getUsercount);
//router.post('/count', userControllerobj.);

var userControllerobj = new userController();
var userValidatorobj = new userValidator();

router.post('/registerOwner', userControllerobj.addOwnerSchema);

router.post('/registerBuilding', userControllerobj.addBuildingSchema);

router.post('/registerFlat', userControllerobj.addFlatSchema);

router.get('/owner', userControllerobj.getOwnerSchema);

router.get('/building', userControllerobj.getBuildingSchema);

router.get('/flat', userControllerobj.getFlatSchema);

router.get('/society', userControllerobj.getSocietySchema);

router.post('/registerSociety', userControllerobj.addSocietySchema);



// router.get('/getsociety', userValidatorobj.validateUser, userControllerobj.getSocietySchema);

router.get('/gettest', userControllerobj.getTestSchema);

router.post('/updateTest', userControllerobj.updateTestSchema);

router.post('/deleteTest', userControllerobj.deleteTestSchema);

router.post('/addtest', userControllerobj.addTestSchema);

router.post('/loginTest', userControllerobj.loginTestShema);


router.get('/gettest', userControllerobj.getTestSchema);

router.get('/:studentName', userControllerobj.getStudentName);





module.exports = router;