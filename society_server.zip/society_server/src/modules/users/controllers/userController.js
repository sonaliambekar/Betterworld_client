var express = require ('express');
//var router = require ('routers');

import userModel from "./../models/userModel"
import { STATUS_CODES } from "http";

//var obj = {
   // count : 0
//}

// module.exports={
//    getUserCount: function(req,res){
//        res.send("Inside Controllre" +obj.count++) 
//     },
//     postUserCount: function(req, res){
//        console.log(req.body.number);
//        console.log(obj.count);
//        obj.count=req.body.number;
//        res.send("Inside Controller" +obj.count)
//     }

// }

var resformat = {
    "fieldCount": 0,
    "affectedRows": 1,
    "insertId": 21,
    "serverStatus": 2,
    "warningCount": 0,
    "message": "",
    "protocol41": true,
    "changedRows": 0
}


class userController{
    constructor(){
        this.userModel = new userModel();
    }
    getUsercount = (req, res) => {
        res.send("User count is"+this.userModel.getUser())
    }
    getStudentName = async (req,res)=>  {
        try{
        console.log("Requested parameter is", req.params.studentName,req.query.value);
        var data = await this.userModel.getUserdetails(req)
            res.send(data);
        }catch(err){
            res.send(err);
        }
        
    }

    getTestSchema = async (req, res) => {
        try{
            var data =await this.userModel.getSociety();
            res.status(200).send(data);
        }
        catch(err){
            res.status(400).send(err);
        }
    }
    
    getSocietySchema = async (req, res) => {
        try{
            var data =await this.userModel.getSociety();
            res.status(200).send({
                "error": '0',
                "data": "",
                "satusCode": '200',
                "dbResponse": data});
        }
        catch(err){
            res.status(400).send(err);
        }
    }

    getFlatSchema = async (req,res) => {
        try{
            var data = await this.userModel.getFlat();
            res.status(200).send({
                "error": '0',
                "data": "",
                "statusCode": '200',
                "dbResponse": data
            });
        } catch(err){
            res.status(400).send(err);
        }
    }


    getBuildingSchema = async (req,res) => {
        try{
            var data = await this.userModel.getBuilding();
            res.status(200).send({
                "error": '0',
                "data": "",
                "statusCode": '200',
                "dbResponse": data
            });
        }
        catch(err){
            res.status(400).send(err);
        }
    }

    getOwnerSchema = async (req,res) => {
        try{
            var data = await this.userModel.getOwner();
            res.status(200).send({
                "error": '0',
                "data": "",
                "statusCode": '200',
                "dbResponse": data
            });
        }
        catch(err){
            res.status(400).send(err);
        }
    }
    

    addSocietySchema = async(req,res) => {     
        try{
            var data = await this.userModel.addSociety(req);
            console.log("Data is", data);
            res.status(200).send({
                "error": 0,
                "data": "",
                "satusCode": 201,
                "dbResponse": resformat});
        } catch(err) {
            res.status(400).send(err);
        }
    }


    addFlatSchema = async(req,res) => {     
        try{
            var data = await this.userModel.addFlat(req);
            console.log("Data is", data);
            res.status(200).send({
                "error": 0,
                "data": "",
                "satusCode": 201,
                "dbResponse": resformat});
        } catch(err) {
            res.status(400).send(err);
        }
    }

    addBuildingSchema = async(req,res) => {     
        try{
            var data = await this.userModel.addBuilding(req);
            console.log("Data is", data);
            res.status(200).send({
                "error": 0,
                "data": "",
                "satusCode": 201,
                "dbResponse": resformat});
        } catch(err) {
            res.status(400).send(err);
        }
    }


    addOwnerSchema = async(req,res) => {     
        try{
            var data = await this.userModel.addOwner(req);
            console.log("Data is", data);
            res.status(200).send({
                "error": 0,
                "data": "",
                "satusCode": 201,
                "dbResponse": resformat});
        } catch(err) {
            res.status(400).send(err);
        }
    }


    addTestSchema = async (req,res) => {
        try{
            console.log("this is data",data1)
            var data1 = await this.userModel.addTest(req);
            console.log("this is data",data1)
            res.status(200).send(data1);
        } catch(err) {
            res.status(400).send(err);
        }
    }

    updateTestSchema = async (req,res) => {
        try{
            var data = await this.userModel.updateTest(req);
            console.log("This is data", data);
            res.status(200).send(data);
        } catch(err) {
            res.status(400).send(err);
        }
    }

    deleteTestSchema = async (req,res) => {
        try{
            var data = await this.userModel.deleteTest(req);
            console.log("This data is", data);
            res.status(200).send(data);
        } catch(err) {
            res.status(400).send(err);
        }
    }

    loginTestShema = async (req,res) => {
        try{
            console.log("inside login test !!!",req.body);
            var data = await this.userModel.loginTest(req);
            console.log("These are Login Credentials", data);
            res.status(200).send(data);
        } catch(err) {
            res.status(400).send(err);
        }
     }

}


export default userController;