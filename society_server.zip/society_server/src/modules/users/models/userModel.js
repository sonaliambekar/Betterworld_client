import { promises } from "fs";
import { Collection } from "mongoose";
import { stringify } from "querystring";

var jwt = require('jsonwebtoken');

var promise = require('promise');

var schemaSociety = require('./../schema/society');
var schemaFlat = require('./../schema/flat');
var schemaBuilding = require('./../schema/building');
var schemaOwner = require('./../schema/owner')


class userModel{
    getUser = () => {
        return 10;
 }

 getUserdetails = (req) => new promise((resolve, reject) => {
    var obj = {
        'err' : '1',
        'sname' : 'abc'
    };
    
    setTimeout(() => {
        resolve(obj);
    },5000);
 })

 getTest = () =>{
    return new Promise((resolve,reject)=>{
        schemaSociety.find({}, (err, result)=>{
            if(err){
                reject(err);
            } else {
                console.log('****', result);
                resolve(result);
            }
        })
    })
 }


 addTest = (req) => {
    return new Promise((resolve,reject) => {
        var username = req.body.username;
        var password = req.body.password;
        schemaSociety.insertMany({username,password}, function(err, result){
            if(err){
                reject(err);
                console.log('error');
            } else {
               console.log('Saved Successfully', result);
               resolve('Saved Successfully', result);
            }
        });
        
    });
}


 getSociety = () =>{
    return new Promise((resolve,reject)=>{
        schemaSociety.find({}, (err, result)=>{
            if(err){
                reject(err);
            } else {
                console.log('****', result);
                resolve(result);
            }
        })
    })
 }

 
 getFlat = () => {
    return new Promise((resolve,reject) => {
       schemaFlat.find({}, (err, result) => {
           if(err){
               reject(err);
           } else {
               console.log('*****', result);
               resolve(result);
           }
       })
    })
}

getBuilding = () => {
    return new Promise((resolve, reject) => {
        schemaBuilding.find({}, (err, result) => {
            if(err){
                reject(err);
            } else {
                console.log('******', result);
                resolve(result);
            }
        });
    });
}

getOwner = () => {
    return new Promise((resolve, reject) => {
        schemaOwner.find({}, (err, result) => {
            if(err){
                reject(err);
            } else {
                console.log('******', result);
                resolve(result);
            }
        });
    });
}

 addSociety = (req) => {
    return new Promise((resolve,reject) => {
        var societyName = req.body.societyName;
        var address = req.body.address;
        var pincode = req.body.pincode;
        
        schemaSociety.insertMany({societyName,address,pincode}, function(err, result){
            if(err){
                reject(err);
                console.log('error');
            } else {
               console.log('Added Successfully', result);
               resolve('Added Successfully', result);
            }
        });
    });
 }


 addFlat = (req) => {
    return new Promise((resolve,reject) => {
        var flatName = req.body.flatName;
        var buildingName = req.body.buildingName;
        var societyId = req.body.societyId;
        
        schemaFlat.insertMany({flatName,buildingName,societyId}, function(err, result){
            if(err){
                reject(err);
                console.log('error');
            } else {
               console.log('Added Successfully', result);
               resolve('Added Successfully', result);
            }
        });
    });
 }


 addBuilding = (req) => {
    return new Promise((resolve,reject) => {
        var buildingName = req.body.buildingName;
        var societyid = req.body.societyid;
        
        schemaBuilding.insertMany({buildingName,societyid}, function(err, result){
            if(err){
                reject(err);
                console.log('error');
            } else {
               console.log('Added Successfully', result);
               resolve('Added Successfully', result);
            }
        });
    });
 }

 addOwner = (req) => {
    return new Promise((resolve,reject) => {
        var ownerName = req.body.ownerName;
        var isAdmin = req.body.isAdmin;
        var phoneNumber = req.body.phoneNumber;
        var email = req.body.email;
        var age = req.body.age;
        var gender = req.body.gender;
        var password = req.body.password;
        var buildingName = req.body.buildingName;
        var societyId = req.body.societyId;
        var flatNumber = req.body.flatNumber;
        
        schemaOwner.insertMany({ownerName,isAdmin,phoneNumber,email,age,gender,password,buildingName,societyId,flatNumber}, function(err, result){
            if(err){
                reject(err);
                console.log('error');
            } else {
               console.log('Added Successfully', result);
               resolve('Added Successfully', result);
            }
        });
    });
 }


 updateTest = (req) =>{
     return new Promise((resolve,reject) => {

        var name = req.body.name;
        //var name = req.body.name;

        schemaSociety.updateOne({name,$set: {name}}, function(err){
             if(err){
                 reject(err);
             } else {
                 console.log('Updated successfully');
                 resolve('Updated Successfully');
             }
         });
     });
 }


 deleteTest = (req) => {
     return new Promise((resolve,reject) => {
         var name= req.body.name;
         schemaSociety.deleteMany({name}, function(err, result){
             if(err){
                 reject(err);
             } else {
                 console.log("deleted successfully", result);
                 resolve("deleted successfully", result);
             }
         });
     });
 }

 

 loginTest = (req) => {
     console.log("inside logintest");
    return new Promise((resolve,reject) => {
        console.log("***********")
        var email = req.body.email;
        var password = req.body.password;
        console.log('data is ',req.body.email);

        schemaSociety.find({username:req.body.email}, (err, result)=>{
            if(err){
                reject(err);
            } else {
                if(result.length>0){
                    console.log('**got result**', result);
                    let token = jwt.sign(req.body, "sonali",{
                        expiresIn:1440
                    })
                    resolve({token:token});
                } else {
                    console.log('**inalid username**');
                    resolve('**inalid username**');
                }
            }
        });
    });
 }

}

export default userModel;