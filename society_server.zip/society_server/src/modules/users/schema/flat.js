var mongoose = require('mongoose');
var Schema1 = mongoose.Schema;


var flatSchema = new Schema1({
    flatName: {type:String, required:true},
    buildingName: {type:String, required: true},
    societyId: {type:String, required: true}
}, {collection: 'flat'});


var test1 = mongoose.model('flat', flatSchema);

module.exports = test1