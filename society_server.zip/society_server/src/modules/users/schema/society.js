var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var societySchema = new Schema({
    //name: String,
    societyName: {type:String, required:true, unique:true},
    address: {type:String, required:true},
    pincode: {type:String, required:true}

    // created_at: Date,
    // updated_at:Date
}, { collection: 'society' });



societySchema.pre('save', function(next){
    var currentDate = new Date();

    this.updated_at = currentDate;
    if(!this.created_at)
    this.created_at = currentDate;

    next();
});



var test = mongoose.model('society', societySchema);


module.exports = test
