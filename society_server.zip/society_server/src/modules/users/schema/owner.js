var mongoose = require('mongoose');
var Schema2 = mongoose.Schema;


var ownerSchema = new Schema2({
    ownerName: {type:String, required: true},
    isAdmin: {type:String, required: true},
    phoneNumber: {type:String, required: true},
    email: {type:String, required: true},
    age: {type:String, required: true},
    gender: {type:String, required: true},
    password: {type:String, required: true},
    buildingName: {type:String, required: true},
    societyId: {type:String, required: true},
    flatNumber: {type:String, required: true},
}, {collection: 'owner'});


var test3 = mongoose.model('owner', ownerSchema);

module.exports = test3