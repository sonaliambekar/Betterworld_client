var mongoose = require('mongoose');
var Schema2 = mongoose.Schema;


var buildingSchema = new Schema2({
    buildingName: {type:String, required: true},
    societyid: {type:String, required: true}
}, {collection: 'building'});


var test2 = mongoose.model('building', buildingSchema);

module.exports = test2