var jwt = require('jsonwebtoken')

class userValidation{
   validateUser = (req,res,next) => {
      console.log("Validate User");
      var token = req.body.token || req.headers['token'];
      var appData = {};
      console.log(token);
      if(token){
         jwt.verify(token,"sonali", function(err) {
            if(err){
               appData['error'] = 1;
               appData['data'] = 'Token is invalid';
               res.status(500).json(appData);
            } else {
               next();
            }
         })
      } else {
         appData['error'] = 1;
         appData['data'] = 'Please send Token';
         res.status(500).json(appData);
      }
   }
}

export default userValidation;