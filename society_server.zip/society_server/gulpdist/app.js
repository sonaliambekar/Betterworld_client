'use strict';

var mongoose = require('mongoose');

var mongoURI;

mongoose.connection.on('open', function (ref) {
    console.log("Connected to Mongo server");
});

mongoose.connection.on('error', function (err) {
    console.log("Could not connect to Database");
    return console.log(err);
});

mongoURI = "mongodb://localhost/meanstack";

module.exports = mongoose.connect(mongoURI);
'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    name: string,
    username: { type: string, required: true, unique: true },
    password: { type: string, required: true },

    created_at: Date,
    updated_at: Date
});

userSchema.pre('save', function (next) {
    var currentDate = new Date();

    this.updated_at = currentDate;
    if (!this.created_at) this.created_at = currentDate;

    next();
});

var test = mongoose.model('test', userSchema);

module.exports = test;
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _regenerator = require("babel-runtime/regenerator");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require("babel-runtime/helpers/asyncToGenerator");

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _userModel = require("./../models/userModel");

var _userModel2 = _interopRequireDefault(_userModel);

var _http = require("http");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var express = require('express');
//var router = require ('routers');

//var obj = {
// count : 0
//}

// module.exports={
//    getUserCount: function(req,res){
//        res.send("Inside Controllre" +obj.count++) 
//     },
//     postUserCount: function(req, res){
//        console.log(req.body.number);
//        console.log(obj.count);
//        obj.count=req.body.number;
//        res.send("Inside Controller" +obj.count)
//     }

// }

var userController = function userController() {
    var _this = this;

    (0, _classCallCheck3.default)(this, userController);

    this.getUsercount = function (req, res) {
        res.send("User count is" + _this.userModel.getUser());
    };

    this.getStudentName = function () {
        var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                        case 0:
                            _context.prev = 0;

                            console.log("Requested parameter is", req.params.studentName, req.query.value);
                            _context.next = 4;
                            return _this.userModel.getUserdetails(req);

                        case 4:
                            data = _context.sent;

                            res.send(data);
                            _context.next = 11;
                            break;

                        case 8:
                            _context.prev = 8;
                            _context.t0 = _context["catch"](0);

                            res.send(_context.t0);

                        case 11:
                        case "end":
                            return _context.stop();
                    }
                }
            }, _callee, _this, [[0, 8]]);
        }));

        return function (_x, _x2) {
            return _ref.apply(this, arguments);
        };
    }();

    this.getTestSchema = function () {
        var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee2$(_context2) {
                while (1) {
                    switch (_context2.prev = _context2.next) {
                        case 0:
                            _context2.prev = 0;
                            _context2.next = 3;
                            return _this.userModel.getSociety();

                        case 3:
                            data = _context2.sent;

                            res.status(200).send(data);
                            _context2.next = 10;
                            break;

                        case 7:
                            _context2.prev = 7;
                            _context2.t0 = _context2["catch"](0);

                            res.status(400).send(_context2.t0);

                        case 10:
                        case "end":
                            return _context2.stop();
                    }
                }
            }, _callee2, _this, [[0, 7]]);
        }));

        return function (_x3, _x4) {
            return _ref2.apply(this, arguments);
        };
    }();

    this.getSocietySchema = function () {
        var _ref3 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee3$(_context3) {
                while (1) {
                    switch (_context3.prev = _context3.next) {
                        case 0:
                            _context3.prev = 0;
                            _context3.next = 3;
                            return _this.userModel.getSociety();

                        case 3:
                            data = _context3.sent;

                            res.status(200).send(data);
                            _context3.next = 10;
                            break;

                        case 7:
                            _context3.prev = 7;
                            _context3.t0 = _context3["catch"](0);

                            res.status(400).send(_context3.t0);

                        case 10:
                        case "end":
                            return _context3.stop();
                    }
                }
            }, _callee3, _this, [[0, 7]]);
        }));

        return function (_x5, _x6) {
            return _ref3.apply(this, arguments);
        };
    }();

    this.addSocietySchema = function () {
        var _ref4 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee4$(_context4) {
                while (1) {
                    switch (_context4.prev = _context4.next) {
                        case 0:
                            _context4.prev = 0;
                            _context4.next = 3;
                            return _this.userModel.addSociety(req);

                        case 3:
                            data = _context4.sent;

                            console.log("Data is", data);
                            res.status(200).send(data);
                            _context4.next = 11;
                            break;

                        case 8:
                            _context4.prev = 8;
                            _context4.t0 = _context4["catch"](0);

                            res.status(400).send(_context4.t0);

                        case 11:
                        case "end":
                            return _context4.stop();
                    }
                }
            }, _callee4, _this, [[0, 8]]);
        }));

        return function (_x7, _x8) {
            return _ref4.apply(this, arguments);
        };
    }();

    this.addTestSchema = function () {
        var _ref5 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
            var data1;
            return _regenerator2.default.wrap(function _callee5$(_context5) {
                while (1) {
                    switch (_context5.prev = _context5.next) {
                        case 0:
                            _context5.prev = 0;

                            console.log("this is data", data1);
                            _context5.next = 4;
                            return _this.userModel.addTest(req);

                        case 4:
                            data1 = _context5.sent;

                            console.log("this is data", data1);
                            res.status(200).send(data1);
                            _context5.next = 12;
                            break;

                        case 9:
                            _context5.prev = 9;
                            _context5.t0 = _context5["catch"](0);

                            res.status(400).send(_context5.t0);

                        case 12:
                        case "end":
                            return _context5.stop();
                    }
                }
            }, _callee5, _this, [[0, 9]]);
        }));

        return function (_x9, _x10) {
            return _ref5.apply(this, arguments);
        };
    }();

    this.updateTestSchema = function () {
        var _ref6 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee6$(_context6) {
                while (1) {
                    switch (_context6.prev = _context6.next) {
                        case 0:
                            _context6.prev = 0;
                            _context6.next = 3;
                            return _this.userModel.updateTest(req);

                        case 3:
                            data = _context6.sent;

                            console.log("This is data", data);
                            res.status(200).send(data);
                            _context6.next = 11;
                            break;

                        case 8:
                            _context6.prev = 8;
                            _context6.t0 = _context6["catch"](0);

                            res.status(400).send(_context6.t0);

                        case 11:
                        case "end":
                            return _context6.stop();
                    }
                }
            }, _callee6, _this, [[0, 8]]);
        }));

        return function (_x11, _x12) {
            return _ref6.apply(this, arguments);
        };
    }();

    this.deleteTestSchema = function () {
        var _ref7 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee7$(_context7) {
                while (1) {
                    switch (_context7.prev = _context7.next) {
                        case 0:
                            _context7.prev = 0;
                            _context7.next = 3;
                            return _this.userModel.deleteTest(req);

                        case 3:
                            data = _context7.sent;

                            console.log("This data is", data);
                            res.status(200).send(data);
                            _context7.next = 11;
                            break;

                        case 8:
                            _context7.prev = 8;
                            _context7.t0 = _context7["catch"](0);

                            res.status(400).send(_context7.t0);

                        case 11:
                        case "end":
                            return _context7.stop();
                    }
                }
            }, _callee7, _this, [[0, 8]]);
        }));

        return function (_x13, _x14) {
            return _ref7.apply(this, arguments);
        };
    }();

    this.loginTestShema = function () {
        var _ref8 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(req, res) {
            var data;
            return _regenerator2.default.wrap(function _callee8$(_context8) {
                while (1) {
                    switch (_context8.prev = _context8.next) {
                        case 0:
                            _context8.prev = 0;

                            console.log("inside login test !!!", req.body);
                            _context8.next = 4;
                            return _this.userModel.loginTest(req);

                        case 4:
                            data = _context8.sent;

                            console.log("These are Login Credentials", data);
                            res.status(200).send(data);
                            _context8.next = 12;
                            break;

                        case 9:
                            _context8.prev = 9;
                            _context8.t0 = _context8["catch"](0);

                            res.status(400).send(_context8.t0);

                        case 12:
                        case "end":
                            return _context8.stop();
                    }
                }
            }, _callee8, _this, [[0, 9]]);
        }));

        return function (_x15, _x16) {
            return _ref8.apply(this, arguments);
        };
    }();

    this.userModel = new _userModel2.default();
};

exports.default = userController;
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _fs = require("fs");

var _mongoose = require("mongoose");

var _querystring = require("querystring");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var jwt = require('jsonwebtoken');

var promise = require('promise');

var testSchema = require('./../schema/schema');

var userModel = function userModel() {
    (0, _classCallCheck3.default)(this, userModel);

    this.getUser = function () {
        return 10;
    };

    this.getUserdetails = function (req) {
        return new promise(function (resolve, reject) {
            var obj = {
                'err': '1',
                'sname': 'abc'
            };

            setTimeout(function () {
                resolve(obj);
            }, 5000);
        });
    };

    this.getTest = function () {
        return new Promise(function (resolve, reject) {
            testSchema.find({}, function (err, result) {
                if (err) {
                    reject(err);
                } else {
                    console.log('****', result);
                    resolve(result);
                }
            });
        });
    };

    this.addTest = function (req) {
        return new Promise(function (resolve, reject) {
            var username = req.body.username;
            var password = req.body.password;
            testSchema.insertMany({ username: username, password: password }, function (err, result) {
                if (err) {
                    reject(err);
                    console.log('error');
                } else {
                    console.log('Saved Successfully', result);
                    resolve('Saved Successfully', result);
                }
            });
        });
    };

    this.getSociety = function () {
        return new Promise(function (resolve, reject) {
            testSchema.find({}, function (err, result) {
                if (err) {
                    reject(err);
                } else {
                    console.log('****', result);
                    resolve(result);
                }
            });
        });
    };

    this.addSociety = function (req) {
        return new Promise(function (resolve, reject) {
            var societyName = req.body.societyName;
            var address = req.body.address;
            var pincode = req.body.pincode;
            testSchema.insertMany({ societyName: societyName, address: address, pincode: pincode }, function (err, result) {
                if (err) {
                    reject(err);
                    console.log('error');
                } else {
                    console.log('Added Successfully', result);
                    resolve('Added Successfully', result);
                }
            });
        });
    };

    this.updateTest = function (req) {
        return new Promise(function (resolve, reject) {

            var name = req.body.name;
            //var name = req.body.name;

            testSchema.updateOne({ name: name, $set: { name: name } }, function (err) {
                if (err) {
                    reject(err);
                } else {
                    console.log('Updated successfully');
                    resolve('Updated Successfully');
                }
            });
        });
    };

    this.deleteTest = function (req) {
        return new Promise(function (resolve, reject) {
            var name = req.body.name;
            testSchema.deleteMany({ name: name }, function (err, result) {
                if (err) {
                    reject(err);
                } else {
                    console.log("deleted successfully", result);
                    resolve("deleted successfully", result);
                }
            });
        });
    };

    this.loginTest = function (req) {
        console.log("inside logintest");
        return new Promise(function (resolve, reject) {
            console.log("***********");
            var email = req.body.email;
            var password = req.body.password;
            console.log('data is ', req.body.email);

            testSchema.find({ username: req.body.email }, function (err, result) {
                if (err) {
                    reject(err);
                } else {
                    if (result.length > 0) {
                        console.log('**got result**', result);
                        var token = jwt.sign(req.body, "sonali", {
                            expiresIn: 1440
                        });
                        resolve({ token: token });
                    } else {
                        console.log('**inalid username**');
                        resolve('**inalid username**');
                    }
                }
            });
        });
    };
};

exports.default = userModel;
'use strict';

var _userController = require('./../controllers/userController');

var _userController2 = _interopRequireDefault(_userController);

var _userValidator = require('./../validator/userValidator');

var _userValidator2 = _interopRequireDefault(_userValidator);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var express = require('express');
var router = express.Router();

//var userController = require('./../controllers/userController');

//router.get('/test', function(req, res){
// res.send("Routing Works");
//})
//var userControllerobj =new userController();
// router.get('/count', userControllerobj.getUsercount);
//router.post('/count', userControllerobj.);

var userControllerobj = new _userController2.default();
var userValidatorobj = new _userValidator2.default();

router.get('/getsociety', userValidatorobj.validateUser, userControllerobj.getSocietySchema);

router.post('/addsociety', userControllerobj.addSocietySchema);

router.get('/gettest', userControllerobj.getTestSchema);

router.post('/updateTest', userControllerobj.updateTestSchema);

router.post('/deleteTest', userControllerobj.deleteTestSchema);

router.post('/addtest', userControllerobj.addTestSchema);

router.post('/loginTest', userControllerobj.loginTestShema);

router.get('/gettest', userControllerobj.getTestSchema);

router.get('/:studentName', userControllerobj.getStudentName);

module.exports = router;
'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    //name: String,
    societyName: { type: String, required: true, unique: true },
    address: { type: String, required: true },
    pincode: { type: String, required: true

        // created_at: Date,
        // updated_at:Date
    } }, { collection: 'society' });

userSchema.pre('save', function (next) {
    var currentDate = new Date();

    this.updated_at = currentDate;
    if (!this.created_at) this.created_at = currentDate;

    next();
});

var test = mongoose.model('society', userSchema);

module.exports = test;
'use strict';

Object.defineProperty(exports, "__esModule", {
   value: true
});

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var jwt = require('jsonwebtoken');

var userValidation = function userValidation() {
   (0, _classCallCheck3.default)(this, userValidation);

   this.validateUser = function (req, res, next) {
      console.log("Validate User");
      var token = req.body.token || req.headers['token'];
      var appData = {};
      console.log(token);
      if (token) {
         jwt.verify(token, "sonali", function (err) {
            if (err) {
               appData['error'] = 1;
               appData['data'] = 'Token is invalid';
               res.status(500).json(appData);
            } else {
               next();
            }
         });
      } else {
         appData['error'] = 1;
         appData['data'] = 'Please send Token';
         res.status(500).json(appData);
      }
   };
};

exports.default = userValidation;