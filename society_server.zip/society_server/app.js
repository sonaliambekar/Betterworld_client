var express = require('express');
var app = express();
var bodyParser = require('body-parser')

//var testRouter = require('./dist/modules/users/routes/userRouter');
//app.use('/test', testRouter);
 app.use(bodyParser.json());
// var count = require('./dist/modules/users/routes/userRouter');
// app.use('/test', count);

var mongo = require('./dist/database/mongo');


var societyP = require('./dist/modules/users/routes/userRouter');
app.use('/society', societyP);


app.listen(3000, function(){
    console.log("Your server is running on port 3000!");
})