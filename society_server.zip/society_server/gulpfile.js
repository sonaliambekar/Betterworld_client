var gulp = require('gulp');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');

gulp.task('default', function(){
    return console.log('Gulp is running');
});

gulp.task('uglify', function(){
    return gulp.src(['dist/**/**/**/*.js'])
    .pipe(uglify())
    .pipe(gulp.dest('gulpdist'));
})

gulp.task('concat', function(){
   return gulp.src(['dist/**/**/**/*.js'])
    .pipe(concat('app.js'))
    .pipe(gulp.dest('gulpdist'));
});