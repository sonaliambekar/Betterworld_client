import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant',
  templateUrl: './tenant.component.html',
  styleUrls: ['./tenant.component.css']
})
export class TenantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
