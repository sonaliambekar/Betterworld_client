import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-society-header',
  templateUrl: './society-header.component.html',
  styleUrls: ['./society-header.component.css']
})
export class SocietyHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
